# Developer Housing Site — FloorMap + Thumbnails
Instrukcja skrócona (Windows):
1) Zainstaluj Node.js LTS 18+
2) W folderze projektu:
   npm install --omit=optional
3) Skopiuj swoje PDF-y do: public/uploads/
4) Wygeneruj miniatury:
   npm run thumbs
5) Uruchom dev serwer:
   npm run dev
6) Otwórz: http://localhost:3000
