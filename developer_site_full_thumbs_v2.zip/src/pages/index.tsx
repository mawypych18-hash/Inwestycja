import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Building2, Filter, ChevronLeft, ChevronRight, Ruler, BedDouble, FileText } from 'lucide-react';

type Unit = {
  id: string; floor: number; number: string;
  rooms: number | null; area: number | null; price: number | null;
  isAvailable: boolean; hasBalcony: boolean; orientation: string; planUrl: string;
};

// --- PDF thumbnail fallback (client-side via PDF.js) ---
function PdfThumb({ url, className }: { url: string; className?: string }) {
  const [dataUrl, setDataUrl] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const pdfjs: any = await import('pdfjs-dist');
        pdfjs.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
        const pdf = await pdfjs.getDocument(url).promise;
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 0.7 });
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if(!ctx) throw new Error('Brak kontekstu 2D');
        canvas.width = Math.floor(viewport.width); canvas.height = Math.floor(viewport.height);
        await page.render({ canvasContext: ctx, viewport }).promise;
        if(!cancelled) setDataUrl(canvas.toDataURL('image/jpeg', 0.85));
      } catch(e: any) {
        if(!cancelled) setError(e?.message || 'Błąd miniatury PDF');
      }
    })();
    return () => { cancelled = true; };
  }, [url]);
  if(error) return <div className={`relative w-full h-full bg-neutral-100 flex items-center justify-center ${className||''}`}><span className="text-xs text-neutral-600">PDF</span></div>;
  if(!dataUrl) return <div className={`relative w-full h-full bg-neutral-100 animate-pulse ${className||''}`}/>;
  return <img src={dataUrl} alt="Podgląd PDF" className={`absolute inset-0 h-full w-full object-cover ${className||''}`} />;
}

// === DANE MIESZKAŃ ===
const UNITS: Unit[] = [
  // --- Klatka A ---
  { id: "A201", floor: 2, number: "2.A.1", rooms: 2, area: 50.57, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.A.1.pdf" },
  { id: "A202", floor: 2, number: "2.A.2", rooms: 2, area: 53.57, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.A.2.pdf" },
  { id: "A203", floor: 2, number: "2.A.3", rooms: 1, area: 30.47, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.A.3.pdf" },
  { id: "A204", floor: 2, number: "2.A.4", rooms: 3, area: 72.54, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.A.4.pdf" },
  { id: "A305", floor: 3, number: "3.A.5", rooms: 2, area: 50.57, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.A.5.pdf" },
  { id: "A306", floor: 3, number: "3.A.6", rooms: 2, area: 53.57, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.A.6.pdf" },
  { id: "A307", floor: 3, number: "3.A.7", rooms: 1, area: 30.47, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.A.7.pdf" },
  { id: "A308", floor: 3, number: "3.A.8", rooms: 3, area: 72.54, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.A.8.pdf" },
  { id: "A409", floor: 4, number: "4.A.9", rooms: 2, area: 50.57, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.A.9.pdf" },
  { id: "A410", floor: 4, number: "4.A.10", rooms: 2, area: 53.57, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.A.10.pdf" },
  { id: "A411", floor: 4, number: "4.A.11", rooms: 1, area: 30.47, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.A.11.pdf" },
  { id: "A412", floor: 4, number: "4.A.12", rooms: 3, area: 72.54, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.A.12.pdf" },

  // --- Klatka B (2. piętro) ---
  { id: "B214", floor: 2, number: "2.B.14", rooms: 1, area: 34.86, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.14.pdf" },
  { id: "B215", floor: 2, number: "2.B.15", rooms: 3, area: 75.39, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.15.pdf" },
  { id: "B216", floor: 2, number: "2.B.16", rooms: 3, area: 56.71, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.16.pdf" },
  { id: "B217", floor: 2, number: "2.B.17", rooms: 1, area: 34.73, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.17.pdf" },
  { id: "B218", floor: 2, number: "2.B.18", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.18.pdf" },
  { id: "B219", floor: 2, number: "2.B.19", rooms: 3, area: 46.01, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.19.pdf" },
  { id: "B220", floor: 2, number: "2.B.20", rooms: 3, area: 48.03, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.20.pdf" },
  { id: "B221", floor: 2, number: "2.B.21", rooms: 3, area: 48.17, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.21.pdf" },
  { id: "B222", floor: 2, number: "2.B.22", rooms: 3, area: 45.78, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.B.22.pdf" },

  // --- Klatka B (3. piętro) ---
  { id: "B323", floor: 3, number: "3.B.23", rooms: 1, area: 34.86, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.23.pdf" },
  { id: "B324", floor: 3, number: "3.B.24", rooms: 3, area: 75.39, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.24.pdf" },
  { id: "B325", floor: 3, number: "3.B.25", rooms: 2, area: 56.71, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.25.pdf" },
  { id: "B326", floor: 3, number: "3.B.26", rooms: 1, area: 34.73, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.26.pdf" },
  { id: "B327", floor: 3, number: "3.B.27", rooms: 2, area: 46.00, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.27.pdf" },
  { id: "B328", floor: 3, number: "3.B.28", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.28.pdf" },
  { id: "B329", floor: 3, number: "3.B.29", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.29.pdf" },
  { id: "B330", floor: 3, number: "3.B.30", rooms: 2, area: 48.17, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.30.pdf" },
  { id: "B331", floor: 3, number: "3.B.31", rooms: 2, area: 45.80, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.B.31.pdf" },

  // --- Klatka B (4. piętro) ---
  { id: "B432", floor: 4, number: "4.B.32", rooms: 1, area: 34.86, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.32.pdf" },
  { id: "B433", floor: 4, number: "4.B.33", rooms: 3, area: 75.39, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.33.pdf" },
  { id: "B434", floor: 4, number: "4.B.34", rooms: 3, area: 56.71, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.34.pdf" },
  { id: "B435", floor: 4, number: "4.B.35", rooms: 1, area: 34.73, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.35.pdf" },
  { id: "B436", floor: 4, number: "4.B.36", rooms: 3, area: 46.00, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.36.pdf" },
  { id: "B437", floor: 4, number: "4.B.37", rooms: 3, area: 46.02, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.37.pdf" },
  { id: "B438", floor: 4, number: "4.B.38", rooms: 3, area: 48.03, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.38.pdf" },
  { id: "B439", floor: 4, number: "4.B.39", rooms: 3, area: 48.17, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.39.pdf" },
  { id: "B440", floor: 4, number: "4.B.40", rooms: 3, area: 45.80, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.B.40.pdf" },

  // --- Klatka C ---
  { id: "C241", floor: 2, number: "2.C.41", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.C.41.pdf" },
  { id: "C242", floor: 2, number: "2.C.42", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.C.42.pdf" },
  { id: "C243", floor: 2, number: "2.C.43", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.C.43.pdf" },
  { id: "C244", floor: 2, number: "2.C.44", rooms: 2, area: 42.64, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.C.44.pdf" },
  { id: "C345", floor: 3, number: "3.C.45", rooms: 1, area: 33.14, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.C.45.pdf" },
  { id: "C346", floor: 3, number: "3.C.46", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.C.46.pdf" },
  { id: "C347", floor: 3, number: "3.C.47", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.C.47.pdf" },
  { id: "C348", floor: 3, number: "3.C.48", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.C.48.pdf" },
  { id: "C449", floor: 4, number: "4.C.49", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.C.49.pdf" },
  { id: "C450", floor: 4, number: "4.C.50", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.C.50.pdf" },
  { id: "C451", floor: 4, number: "4.C.51", rooms: 3, area: 51.14, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.C.51.pdf" },
  { id: "C452", floor: 4, number: "4.C.52", rooms: 2, area: 42.64, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.C.52.pdf" },

  // --- Klatka D (2. piętro) ---
  { id: "D253", floor: 2, number: "2.D.53", rooms: 1, area: 33.06, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.D.53.pdf" },
  { id: "D254", floor: 2, number: "2.D.54", rooms: 1, area: 47.11, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.D.54.pdf" },
  { id: "D255", floor: 2, number: "2.D.55", rooms: 3, area: 79.54, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.D.55.pdf" },
  { id: "D256", floor: 2, number: "2.D.56", rooms: 2, area: 45.59, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.D.56.pdf" },
  { id: "D257", floor: 2, number: "2.D.57", rooms: 2, area: 46.45, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.D.57.pdf" },
  { id: "D258", floor: 2, number: "2.D.58", rooms: 3, area: 58.59, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.D.58.pdf" },
  { id: "D259", floor: 2, number: "2.D.59", rooms: 2, area: 46.67, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.D.59.pdf" },
  { id: "D260", floor: 2, number: "2.D.60", rooms: 3, area: 65.33, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/2.D.60.pdf" },

  // --- Klatka D (3. piętro) ---
  { id: "D361", floor: 3, number: "3.D.61", rooms: 1, area: 33.06, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.D.61.pdf" },
  { id: "D362", floor: 3, number: "3.D.62", rooms: 2, area: 46.35, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.D.62.pdf" },
  { id: "D363", floor: 3, number: "3.D.63", rooms: 3, area: 79.54, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.D.63.pdf" },
  { id: "D364", floor: 3, number: "3.D.64", rooms: 2, area: 45.59, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.D.64.pdf" },
  { id: "D365", floor: 3, number: "3.D.65", rooms: 2, area: 46.45, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.D.65.pdf" },
  { id: "D366", floor: 3, number: "3.D.66", rooms: 3, area: 58.59, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.D.66.pdf" },
  { id: "D367", floor: 3, number: "3.D.67", rooms: 2, area: 46.67, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.D.67.pdf" },
  { id: "D368", floor: 3, number: "3.D.68", rooms: 4, area: 69.05, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/3.D.68.pdf" },

  // --- Klatka D (4. piętro) ---
  { id: "D469", floor: 4, number: "4.D.69", rooms: 1, area: 33.06, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.D.69.pdf" },
  { id: "D470", floor: 4, number: "4.D.70", rooms: 2, area: 46.35, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.D.70.pdf" },
  { id: "D471", floor: 4, number: "4.D.71", rooms: 3, area: 79.54, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.D.71.pdf" },
  { id: "D472", floor: 4, number: "4.D.72", rooms: 2, area: 45.59, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.D.72.pdf" },
  { id: "D473", floor: 4, number: "4.D.73", rooms: null, area: null, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.D.73.pdf" },
  { id: "D474", floor: 4, number: "4.D.74", rooms: 3, area: 58.59, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.D.74.pdf" },
  { id: "D475", floor: 4, number: "4.D.75", rooms: 2, area: 46.67, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.D.75.pdf" },
  { id: "D476", floor: 4, number: "4.D.76", rooms: 4, area: 69.05, price: null, isAvailable: true, hasBalcony: true, orientation: "", planUrl: "/uploads/4.D.76.pdf" }
];

const HERO_IMAGES = [
  "/uploads/Siedlce_Inicjatywa_uj02b.jpg",
  "/uploads/Siedlce_Inicjatywa_uj02vbezdrzew_001.jpg",
  "/uploads/Siedlce_Inicjatywa_uj01b.jpg",
];

export default function HomePage() {
  const [rooms, setRooms] = useState<string>("0");
  const [area, setArea] = useState<[number, number]>([25, 120]);
  const [floor, setFloor] = useState<number | "">("");
  const [query, setQuery] = useState("");

  const floors = Array.from(new Set(UNITS.map(u=>u.floor))).sort((a,b)=>b-a);
  const filtered = useMemo(()=> UNITS.filter(u =>
    (rooms==="0" || (typeof u.rooms==='number' && u.rooms===Number(rooms))) &&
    ((u.area==null) || (u.area>=area[0] && u.area<=area[1])) &&
    (floor==="" || u.floor===floor) &&
    (query==="" || `${u.number}`.toLowerCase().includes(query.toLowerCase()))
  ), [rooms, area, floor, query]);

  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 z-40 border-b bg-white/80 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 py-3 flex items-center gap-3">
          <Building2 className="h-6 w-6"/><div className="font-semibold">Nowe Apartamenty – FloorMap</div>
          <div className="ml-auto hidden md:flex items-center gap-2">
            <input placeholder="Szukaj numeru (np. 3.B.24)" value={query} onChange={e=>setQuery(e.target.value)} className="w-72 border rounded-lg px-3 py-2"/>
          </div>
          <button className="md:hidden rounded-lg border px-2 py-2"><Filter className="h-4 w-4"/></button>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-4 py-8">
        <h1 className="text-3xl font-bold tracking-tight mb-2">Wizualizacje inwestycji</h1>
        <Carousel images={HERO_IMAGES}/>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-6 grid lg:grid-cols-2 gap-6">
        <div>
          <h2 className="text-2xl font-semibold">Wybierz mieszkanie</h2>
          <div className="mt-3 flex flex-wrap gap-2 items-center">
            <label className="text-sm">Pokoje:
              <select value={rooms} onChange={e=>setRooms(e.target.value)} className="ml-2 border rounded px-2 py-1">
                <option value="0">wszystkie</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </label>
            <label className="text-sm">Metraż:
              <input type="range" min={25} max={120} value={area[1]} onChange={e=>setArea([25, Number(e.target.value)])} className="ml-2"/>
              <span className="ml-2">do {area[1]} m²</span>
            </label>
          </div>
          <div className="mt-4 grid grid-cols-12 gap-2">
            <div className="col-span-4 flex flex-col gap-1 max-h-[420px] overflow-auto pr-1">
              {floors.map(f=>{
                const total = UNITS.filter(u=>u.floor===f).length;
                const free = UNITS.filter(u=>u.floor===f && u.isAvailable).length;
                return (
                  <button key={f} onClick={()=>setFloor(f)} className={`flex items-center justify-between rounded-xl border px-3 py-2 text-sm ${floor===f?"border-black":"border-neutral-200 hover:border-neutral-300"}`}>
                    <span>Piętro {f}</span><span className="text-xs text-neutral-600">{free}/{total}</span>
                  </button>
                );
              })}
              <button onClick={()=>setFloor("")} className="mt-2 text-left text-xs underline">Pokaż wszystkie piętra</button>
            </div>
            <div className="col-span-8">
              <div className="aspect-[4/3] rounded-2xl border p-3">
                <FloorMap floor={floor || floors[0]} units={UNITS.filter(u=>u.floor===(floor || floors[0]))} onSelect={(num)=>{
                  const sel = UNITS.find(u=>u.number===num); if(sel) window.open(sel.planUrl, '_blank');
                }}/>
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="font-medium text-neutral-600 mb-2">Znaleziono: {filtered.length}</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filtered.map(u=> (
              <div key={u.id} className="rounded-2xl border p-3 hover:shadow transition">
                <div className="relative aspect-video bg-neutral-100 rounded-xl overflow-hidden">
                  {u.planUrl?.toLowerCase().endsWith('.pdf') ? (()=>{
                    const jpg = u.planUrl.replace('/uploads/','/thumbnails/').replace(/\.pdf$/i,'.jpg');
                    return (<>
                      <img src={jpg} alt={`Miniatura ${u.number}`} className="absolute inset-0 h-full w-full object-cover"
                           onError={(e)=>{ (e.currentTarget as HTMLImageElement).style.display='none'; }} />
                      <PdfThumb url={u.planUrl} />
                      <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center">
                        <span className="inline-flex items-center gap-2 text-xs px-2 py-1 rounded bg-white/85 backdrop-blur border">
                          <FileText className="h-4 w-4"/> PDF – 1. strona
                        </span>
                        <button onClick={()=>window.open(u.planUrl,'_blank')} className="text-xs px-2 py-1 rounded bg-white/90 backdrop-blur border hover:bg-white">
                          Otwórz PDF
                        </button>
                      </div>
                    </>);
                  })() : (
                    <img alt={`Rzut ${u.number}`} src={u.planUrl || "https://dummyimage.com/900x600/eeeeee/222&text=Rzut"} className="absolute inset-0 h-full w-full object-cover"/>
                  )}
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <div className="font-semibold">{u.number}</div>
                  <div className="text-sm text-neutral-600 flex items-center gap-3">
                    <span className="inline-flex items-center gap-1"><Ruler className="h-4 w-4"/>{u.area ?? "—"} m²</span>
                    <span className="inline-flex items-center gap-1"><BedDouble className="h-4 w-4"/>{u.rooms ?? "—"} pok.</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t">
        <div className="mx-auto max-w-7xl px-4 py-6 text-sm text-neutral-600">© 2025 Primo Development</div>
      </footer>
    </div>
  );
}

function Carousel({images}:{images:string[]}){
  const [index, setIndex] = React.useState(0);
  const next = ()=> setIndex(i=> (i+1)%images.length);
  const prev = ()=> setIndex(i=> (i-1+images.length)%images.length);
  return (
    <div className="relative">
      <div className="aspect-[21/9] w-full overflow-hidden rounded-2xl border">
        <AnimatePresence mode="wait">
          <motion.img key={images[index]} src={images[index]} alt={`Slajd ${index+1}`} className="h-full w-full object-cover"
            initial={{opacity:0, scale:0.98}} animate={{opacity:1, scale:1}} exit={{opacity:0, scale:1.02}} transition={{duration:0.35}}/>
        </AnimatePresence>
      </div>
      <button onClick={prev} className="absolute left-3 top-1/2 -translate-y-1/2 bg-white/90 rounded-full p-2 shadow"><ChevronLeft/></button>
      <button onClick={next} className="absolute right-3 top-1/2 -translate-y-1/2 bg-white/90 rounded-full p-2 shadow"><ChevronRight/></button>
    </div>
  );
}

function FloorMap({floor, units, onSelect}:{floor:number, units:Unit[], onSelect:(n:string)=>void}){
  const sorted = [...units].sort((a,b)=> (a.number > b.number ? 1 : -1));
  return (
    <div className="h-full w-full flex flex-col">
      <div className="font-medium mb-2">Piętro {floor}</div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 overflow-auto h-full">
        {sorted.map(u=> (
          <button key={u.id} onClick={()=> onSelect(u.number)} className="rounded-xl border p-3 text-left hover:shadow">
            <div className="font-semibold">{u.number}</div>
            <div className="text-xs text-neutral-600">{u.rooms ?? "—"} pok. / {u.area ?? "—"} m²</div>
          </button>
        ))}
      </div>
    </div>
  );
}
