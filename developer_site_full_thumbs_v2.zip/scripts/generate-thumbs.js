// scripts/generate-thumbs.js
// Generator miniaturek JPG (1. strona PDF) dla wszystkich plików w public/uploads/
// Zapisuje wynik do public/thumbnails/
// Używa lokalnego serwera Express i Puppeteera z PDF.js z CDN.

const fs = require("fs");
const path = require("path");
const express = require("express");
const puppeteer = require("puppeteer");

const PUBLIC_DIR = path.join(process.cwd(), "public");
const UPLOADS_DIR = path.join(PUBLIC_DIR, "uploads");
const THUMBS_DIR = path.join(PUBLIC_DIR, "thumbnails");
const PORT = 4000;

async function ensureDirs() {
  if (!fs.existsSync(UPLOADS_DIR)) {
    throw new Error(`Nie znaleziono katalogu: ${UPLOADS_DIR}`);
  }
  if (!fs.existsSync(THUMBS_DIR)) {
    fs.mkdirSync(THUMBS_DIR, { recursive: true });
  }
}

function listPdfs() {
  return fs
    .readdirSync(UPLOADS_DIR)
    .filter((f) => f.toLowerCase().endsWith(".pdf"))
    .sort();
}

function buildHtml(pdfUrl) {
  return `<!doctype html>
<html>
  <head><meta charset="utf-8"/></head>
  <body style="margin:0;padding:0;background:#fff">
    <canvas id="c"></canvas>
    <script type="module">
      import * as pdfjsLib from "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.mjs";
      pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
      const loadingTask = pdfjsLib.getDocument("${pdfUrl}");
      const pdf = await loadingTask.promise;
      const page = await pdf.getPage(1);

      const viewport0 = page.getViewport({ scale: 1 });
      const scale = 1000 / viewport0.width; // docelowa szerokość ok. 1000 px
      const viewport = page.getViewport({ scale });

      const canvas = document.getElementById("c");
      const ctx = canvas.getContext("2d");
      canvas.width = Math.floor(viewport.width);
      canvas.height = Math.floor(viewport.height);

      await page.render({ canvasContext: ctx, viewport }).promise;
      document.title = "READY";
    </script>
  </body>
</html>`;
}

async function startServer() {
  const app = express();
  app.use(express.static(PUBLIC_DIR));
  return new Promise((resolve) => {
    const srv = app.listen(PORT, () => resolve(srv));
  });
}

async function main() {
  await ensureDirs();
  const pdfs = listPdfs();
  if (!pdfs.length) {
    console.log("Brak PDF-ów w", UPLOADS_DIR);
    return;
  }

  const server = await startServer();
  console.log(`Serwuję ${PUBLIC_DIR} na http://localhost:${PORT}`);

  const browser = await puppeteer.launch({ headless: "new" });
  const page = await browser.newPage();
  await page.setViewport({ width: 1000, height: 800 });

  let ok = 0, fail = 0;

  for (const pdf of pdfs) {
    const name = pdf.replace(/\.pdf$/i, "");
    const out = path.join(THUMBS_DIR, `${name}.jpg`);
    const pdfUrl = `http://localhost:${PORT}/uploads/${encodeURIComponent(pdf)}`;

    console.log(`→ Generuję miniaturę: ${pdf} → thumbnails/${name}.jpg`);

    const html = buildHtml(pdfUrl);
    await page.setContent(html, { waitUntil: "domcontentloaded" });

    try {
      await page.waitForFunction(() => document.title === "READY", {
        timeout: 30000,
      });
    } catch {
      console.warn(`! Błąd renderu: ${pdf}`);
      fail++;
      continue;
    }

    const canvas = await page.$("#c");
    if (!canvas) {
      console.warn(`! Brak canvas: ${pdf}`);
      fail++;
      continue;
    }

    await canvas.screenshot({ path: out, type: "jpeg", quality: 85 });
    ok++;
  }

  await browser.close();
  server.close();

  console.log(`\nZakończono. OK: ${ok}, błędy: ${fail}`);
  console.log(`Miniatury w: ${THUMBS_DIR}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
